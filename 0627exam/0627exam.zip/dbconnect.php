<?php

    $con = mysqli_connect("localhost","root","","ssp1");
    mysqli_set_charset($con,"utf8mb4");

?>